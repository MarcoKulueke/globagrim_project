# Installation
```pip install git+git://github.com/MarcoKulueke/globagrim_project.git#egg=globagrim```

# Usage
```from globagrim import globagrim
globagrim.globagrim()```
